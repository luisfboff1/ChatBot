
import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { prisma } from '@/lib/db';
import { buildSystemPrompt } from '@/lib/prompt';

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

export async function POST(req: NextRequest) {
  const { message } = await req.json();
  const tenantId = req.headers.get('x-tenant-id');
  if (!tenantId) return new NextResponse('Missing x-tenant-id', { status: 400 });
  if (!message || typeof message !== 'string') return new NextResponse('Missing message', { status: 400 });

  // Get or create a conversation for demo
  let conv = await prisma.conversation.findFirst({ where: { tenantId }, orderBy: { createdAt: 'desc' } });
  if (!conv) conv = await prisma.conversation.create({ data: { tenantId, title: 'Conversa' } });

  const systemPrompt = await buildSystemPrompt(tenantId);

  await prisma.message.create({ data: { conversationId: conv.id, role: 'user', text: message } });

  let reply = '';
  if (openai) {
    const chat = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ]
    });
    reply = chat.choices[0]?.message?.content || 'Sem resposta.';
  } else {
    // Mock: simple echo with system prompt flavor
    reply = `(${systemPrompt.split('\n')[0]}) Resposta mock: "${message}"`;
  }

  await prisma.message.create({ data: { conversationId: conv.id, role: 'assistant', text: reply } });

  return NextResponse.json({ reply });
}
