
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function GET() {
  const tenants = await prisma.tenant.findMany({ orderBy: { createdAt: 'asc' } });
  return NextResponse.json(tenants.map(t => ({ id: t.id, name: t.name })));
}
