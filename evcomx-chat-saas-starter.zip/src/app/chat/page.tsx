
'use client';
import React, { useEffect, useMemo, useRef, useState } from 'react';

export default function ChatPage({ searchParams }: any) {
  const tenant = searchParams?.tenant as string | undefined;
  const [messages, setMessages] = useState<{role:string; text:string;}[]>([]);
  const [input, setInput] = useState('');

  const sys = useMemo(() => messages.find(m => m.role === 'system')?.text ?? '', [messages]);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!tenant) return;
    fetch('/api/bootstrap?tenant=' + tenant).then(r=>r.json()).then((boot) => {
      setMessages(boot.messages);
    });
  }, [tenant]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  async function send() {
    if (!input.trim()) return;
    const userMsg = { role: 'user', text: input };
    setInput('');
    setMessages(prev => [...prev, userMsg]);
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-tenant-id': tenant || '' },
      body: JSON.stringify({ message: input })
    });
    const data = await res.json();
    setMessages(prev => [...prev, { role: 'assistant', text: data.reply }]);
  }

  return (
    <div className="container">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <a href="/" className="badge">← Voltar</a>
        <span className="badge">Tenant: {tenant || 'não definido'}</span>
      </div>
      {sys && (
        <div className="card" style={{ marginTop: 12 }}>
          <strong>System Prompt Atual</strong>
          <pre style={{ whiteSpace: 'pre-wrap' }}>{sys}</pre>
        </div>
      )}
      <div ref={listRef} style={{ maxHeight: 360, overflow: 'auto', marginTop: 12 }}>
        {messages.map((m, i) => (
          <div key={i} className={`message ${m.role}`}>
            <strong>{m.role}:</strong> {m.text}
          </div>
        ))}
      </div>
      <div className="row" style={{ marginTop: 12 }}>
        <textarea value={input} onChange={e => setInput(e.target.value)} placeholder="Digite sua mensagem..." />
      </div>
      <div className="row" style={{ justifyContent: 'flex-end' }}>
        <button className="button" onClick={send}>Enviar</button>
      </div>
    </div>
  );
}
