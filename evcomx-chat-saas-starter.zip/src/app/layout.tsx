
import './globals.css';
import React from 'react';

export const metadata = {
  title: 'Evcomx Chat SaaS Starter',
  description: 'Multi-tenant chatbot starter'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-gray-50">
        <div className="mx-auto max-w-3xl p-6">
          <header className="mb-6">
            <h1 className="text-2xl font-semibold">Evcomx Chat SaaS Starter</h1>
            <p className="text-sm text-gray-600">Multi-tenant + Prompt Overrides + Chat demo</p>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
