
'use client';
import React, { useEffect, useState } from 'react';

export default function Home() {
  const [tenants, setTenants] = useState<any[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [info, setInfo] = useState<any>(null);

  useEffect(() => {
    fetch('/api/tenants').then(r => r.json()).then(setTenants);
  }, []);

  useEffect(() => {
    if (selected) {
      fetch('/api/tenant-info?tenant=' + selected).then(r => r.json()).then(setInfo);
    } else {
      setInfo(null);
    }
  }, [selected]);

  return (
    <div className="container">
      <h2>Selecione um Tenant</h2>
      <p className="text-sm">Este projeto já vem com 2 tenants de exemplo quando você roda o seed.</p>
      <div className="row" style={{ marginTop: 8 }}>
        <select value={selected} onChange={e => setSelected(e.target.value)}>
          <option value="">-- selecione --</option>
          {tenants.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        {selected && <a className="button" href={`/chat?tenant=${selected}`}>Ir para o Chat</a>}
      </div>

      {info && (
        <div style={{ marginTop: 16 }} className="card">
          <div className="row">
            <span className="badge">Tenant</span>
            <strong>{info.name}</strong>
          </div>
          <div className="row">
            <span className="badge">Plano</span>
            <span>{info.plan}</span>
          </div>
          <div className="row">
            <span className="badge">Prompt</span>
            <span style={{ fontFamily: 'monospace' }}>{info.systemPrompt}</span>
          </div>
        </div>
      )}
    </div>
  );
}
