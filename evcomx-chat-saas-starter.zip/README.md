
# Evcomx Chat SaaS Starter

**Pronto para rodar em `.dev`** com multi-tenant básico, PromptOps (template global + override por tenant), chat UI simples e Postgres via Docker.

## Requisitos
- Node 18+
- Docker (para Postgres)
- (Opcional) OPENAI_API_KEY para usar modelo real; sem isso o backend responde em modo **mock**.

## Passo a passo

```bash
# 1) Clone/extraia e entre na pasta
cp -R evcomx-chat-saas-starter ~/evcomx-chat-saas-starter
cd ~/evcomx-chat-saas-starter

# 2) Suba o Postgres local
docker compose up -d

# 3) Copie variáveis de ambiente
cp .env.example .env

# 4) Instale deps
npm i

# 5) Prepare o banco (schemas + seed demo)
npm run db:push
npm run db:seed

# 6) Rode em desenvolvimento
npm run dev
```

Abra **http://localhost:3000**. Se você rodou o seed, haverá **2 tenants de exemplo**.
Na home selecione um tenant e clique em **Ir para o Chat**.

### Chave OpenAI (opcional)
Edite `.env` e defina `OPENAI_API_KEY=...`. Sem isso, o endpoint `/api/chat` usa um modo **mock** que ecoa a mensagem com o system prompt.

## Onde editar
- **Prompt global**: Prisma -> `PromptTemplate` com `key=system_chatbot`.
- **Override por tenant**: tabela `PromptOverride` (um por tenant/template).
- **API do chat**: `src/app/api/chat/route.ts` (trocar modelo, log, custos, etc.)
- **UI**: `src/app/chat/page.tsx`.

## Multi-tenancy (demo)
- O tenant é resolvido via `?tenant=<id>` na UI e header `x-tenant-id` nos calls.
- Toda query de dados no demo filtra por `tenantId`.
- Em produção, implemente RBAC, RLS e middlewares de auth (Auth.js/OAuth/JWT).

## Próximos passos
- Auth real (Auth.js) com organizações e convites.
- RLS no banco (ex.: Postgres policies).
- Billing e limites por plano (Stripe/Pagar.me).
- Vetor DB para memórias/RAG (pgvector/Pinecone) com namespace por tenant.
- Observabilidade (OpenTelemetry/Langfuse) e auditoria.
