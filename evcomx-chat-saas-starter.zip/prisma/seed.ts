
import { PrismaClient, Role } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const createSample = process.env.SEED_CREATE_SAMPLE_DATA === 'true';

  // Global prompt templates
  const sysTemplate = await prisma.promptTemplate.upsert({
    where: { key: 'system_chatbot' },
    update: {},
    create: {
      key: 'system_chatbot',
      content: 'Você é um assistente da empresa {{tenant_name}}. Seja objetivo, amistoso e responda em português do Brasil.',
      version: 1,
      isGlobal: true
    }
  });

  if (createSample) {
    const tenantA = await prisma.tenant.create({ data: { name: 'Cliente A', plan: 'pro' } });
    const tenantB = await prisma.tenant.create({ data: { name: 'Cliente B', plan: 'free' } });

    const user = await prisma.user.upsert({
      where: { email: 'demo@evcomx.dev' },
      update: {},
      create: { email: 'demo@evcomx.dev', name: 'Demo User' }
    });

    await prisma.membership.create({
      data: { userId: user.id, tenantId: tenantA.id, role: Role.OWNER }
    });
    await prisma.membership.create({
      data: { userId: user.id, tenantId: tenantB.id, role: Role.ADMIN }
    });

    // Override example for tenant B
    await prisma.promptOverride.create({
      data: {
        tenantId: tenantB.id,
        templateId: sysTemplate.id,
        content: 'Você é um assistente hiper sucinto da {{tenant_name}}. Responda em bullet points.'
      }
    });

    const conv = await prisma.conversation.create({
      data: { tenantId: tenantA.id, title: 'Boas-vindas' }
    });

    await prisma.message.createMany({
      data: [
        { conversationId: conv.id, role: 'system', text: 'Contexto inicial', },
        { conversationId: conv.id, role: 'user', text: 'Olá, tudo bem?' },
        { conversationId: conv.id, role: 'assistant', text: 'Tudo ótimo! Como posso ajudar hoje?' }
      ]
    });

    console.log('Seeded tenants/users/prompts/conversation.');
  } else {
    console.log('Global prompts ensured; skipping sample data.');
  }
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
